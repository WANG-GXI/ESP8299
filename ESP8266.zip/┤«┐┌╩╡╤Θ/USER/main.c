#include "delay.h"
#include "sys.h"
#include "usart.h"
#include "uart4.h" 
#include "openmv.h"
#include "lcd.h"

/************************************************
 ALIENTEKս��STM32������ʵ��4
 ����ʵ�� 
 ����֧�֣�www.openedv.com
 �Ա����̣�http://eboard.taobao.com 
 ��ע΢�Ź���ƽ̨΢�źţ�"����ԭ��"����ѻ�ȡSTM32���ϡ�
 �������������ӿƼ����޹�˾  
 ���ߣ�����ԭ�� @ALIENTEK
 
 
 
 ��ɫ ��ɫ ��ɫ ��ɫ
************************************************/

/******************
��ֵд�����麯��
�ú���ʹ��ǰ�� if��com1_data==10��


*************************/
const int spp[6]={6,6,6,6,6,6};		//��������
//int Get_keybord()
//{
//		
//	if(com1_data == 10) return 1;
//	
//	if(com1_data == 12) return 2;
//	
//	if(com1_data == 14) return 3;
//	
//	if(com1_data == 16) return 4;
//		switch(com1_data)
//		{
//			case 1:		LCD_ShowNum(0,40,1,2,24);break;
//			case 2:		LCD_ShowNum(0,40,2,2,24);break;
//			case 3:		LCD_ShowNum(0,40,3,2,24);break;
//			case 4:		LCD_ShowNum(0,40,4,2,24);break;
//			case 5:		LCD_ShowNum(0,40,5,2,24);break;
//			case 6:		LCD_ShowNum(0,40,6,2,24);break;
//			case 7:		LCD_ShowNum(0,40,7,2,24);break;
//			case 8:		LCD_ShowNum(0,40,8,2,24);break;
//			case 9:		LCD_ShowNum(0,40,9,2,24);break;
//				
//			
//		}
//	
//}

 int main(void)
 {	
			
  	vu8 key=0;							//�����洢	 
		int siky,xinlv=0;
	  char temp1[500];
	 sprintf(temp1,"POST /devices/652936501/datapoints?type=5 HTTP/1.1\r\napi-key:RiplobQgl=D=XOnlhXyo=H8h7HM=\r\nHost:api.heclouds.com\r\nContent-Length:11\r\n\r\n,;temp3,%d",xinlv);
	delay_init();	    	 //��ʱ������ʼ��	  
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2); //����NVIC�жϷ���2:2λ��ռ���ȼ���2λ��Ӧ���ȼ�
	uart_init(115200);	 //���ڳ�ʼ��Ϊ115200
	uart4_Init();
	LCD_Init();
	 KEY_Init();         	//��ʼ���밴�����ӵ�Ӳ���ӿ�
	POINT_COLOR=RED;
  	while(1) 
	{	
		
		
		key = KEY_Scan(0);
		if(key)
		{						   
			switch(key)
			{				 
			
				case KEY1_PRES:	
					siky = UART4_Send_AT_Command_End("AT","OK",2,50);//����ͨ���Ƿ�ɹ�
				if(siky == 1)
				{
					siky =  UART4_Send_AT_Command_End("AT+CWMODE=3","OK",2,50);//����ͨ���Ƿ�ɹ�
				  if(siky==1)
					{
						siky = UART4_Send_AT_Command_End("AT+CIPSTART=\"TCP\",\"183.230.40.33\",80","CONNECT",2,50);//����ͨ���Ƿ�ɹ�
						if(siky==1)
							{
								siky = UART4_Send_AT_Command_End("AT+CIPMODE=1","OK",2,50);//����ͨ���Ƿ�ɹ�
									if(siky==1)
										{
											siky = UART4_Send_AT_Command_End("AT+CIPSEND","OK",2,50);//����ͨ���Ƿ�ɹ�											
										}
							}
					
					}
					
				}	
			
			break;
			case WKUP_PRES:	
					if(siky==1)  UART4_Send_Command(temp1);
			break;
			
			case KEY0_PRES:						
						
					xinlv++;
					sprintf(temp1,"POST /devices/652936501/datapoints?type=5 HTTP/1.1\r\napi-key:RiplobQgl=D=XOnlhXyo=H8h7HM=\r\nHost:api.heclouds.com\r\nContent-Length:11\r\n\r\n,;temp3,%d",xinlv);
					break;
			}
		}
		
//			siky = Get_keybord();
//		
//		if(siky==1)  LCD_ShowNum(0,40,1,3,24);	
//		if(siky==2)  LCD_ShowNum(0,40,3,3,24);	
//		if(siky==3)  LCD_ShowNum(0,40,5,3,24);	
//		if(siky==4)  LCD_ShowNum(0,40,7,3,24);	
//			//Get_keybord();
	
	} 
		
	
//	for(i=0;i<6;i++)
			//{
					
			
			//}		
			
//	}	 
	  
 }

/***********************
 
 import sensor, image, time, pyb, ustruct
from pyb import UART

red_threshold_01 = (4, 88, 9, 127, -68, 127)#(50, 65, 60, 80, 30, 60)
uart=UART(3,115200,timeout_char=10000000)
sensor.reset()
sensor.set_pixformat(sensor.RGB565)
sensor.set_framesize(sensor.QQVGA)
sensor.skip_frames(10)
sensor.set_auto_whitebal(False)
clock = time.clock()
led = pyb.LED(3)

def sending_data(cx,cy):    #���ͺ���
    global uart;
    #frame=[0x2C,18,cx%0xff,int(cx/0xff),cy%0xff,int(cy/0xff),0x5B];
    #data = bytearray(frame)
    data = ustruct.pack("<bbhhb",              
                   0x2C,                       
                   0x12,                       
                   int(cx),                    
                   int(cy),                    
                   0x5B)
    uart.write(data);

def recive_data():   #���պ���
    global uart
    if uart.any():
        tmp_data = int(uart.readline())
        print(tmp_data)

while(True):
    #flag=recive_data()
    clock.tick()
    img = sensor.snapshot().lens_corr(1.7)
    blobs = img.find_blobs([red_threshold_01],x_stride=1,y_stride=1,pixels_threshold=12)
    #led.on()
    #flag=recive_data()
    #print(flag)
    #if flag==1:
        #if blobs:
                        #for b in blobs:
                            #img.draw_cross(b[5], b[6]) # cx, cy
                            #print(b[5],b[6])
                            #sending_data(b[5],b[6])
    if uart.any():
                                tmp_data = int(uart.readline())
                                print(tmp_data)
                                while tmp_data==1:
                                    if blobs:
                                                for b in blobs:
                                                    img.draw_cross(b[5], b[6]) # cx, cy
                                                    print(b[5],b[6])
                                                    sending_data(b[5],b[6])
                

 
 ************************/
 
 






